(function(){
    console.log('iffe working')
    // gets users from twitter - search 
    function getUsers(user) {
        var xhttp = new XMLHttpRequest();
        // xhttp.onreadystatechange = function() {
        //     if (xhttp.readyState == 4 && xhttp.status == 200) {
        //         var notes = JSON.parse(xhttp.responseText || []);
        //     }
        // };
        xhttp.open('GET', '/lookup/' + encodeURIComponent(user) + "/notes");
        xhttp.send();
    }

    
    console.log(document.getElementById('sub_btn'));
})();