(function(){
    console.log('iffe working')
    document.getElementById('search').addEventListener('blur', function () {
        console.log(document.getElementById('search').value);
        document.getElementById('btn').href = '/lookup/' + document.getElementById('search').value;
    });
})();